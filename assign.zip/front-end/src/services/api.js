import axios from 'axios';

export const translateText = async (text, sourceLang, targetLang) => {
    const response = await axios.post('http://localhost:5000/api/translate', {
        text, sourceLang, targetLang
    });
    return response.data.translatedText;
};
