import React, { useState } from 'react';
import { translateText } from '../services/api';

const TranslationForm = () => {
    const [text, setText] = useState('');
    const [sourceLang, setSourceLang] = useState('en');
    const [targetLang, setTargetLang] = useState('fr');
    const [translatedText, setTranslatedText] = useState('');

    const handleTranslate = async () => {
        const result = await translateText(text, sourceLang, targetLang);
        setTranslatedText(result);
    };

    return (
        <div className="p-4 bg-gray-100 rounded-lg shadow-md">
            <h2 className="text-xl font-bold mb-2">Text Translation</h2>
            <textarea
                className="w-full p-2 border rounded"
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Enter text to translate..."
            ></textarea>
            <div className="flex gap-2 my-2">
                <select value={sourceLang} onChange={(e) => setSourceLang(e.target.value)}>
                    <option value="en">English</option>
                    <option value="es">Spanish</option>
                </select>
                <select value={targetLang} onChange={(e) => setTargetLang(e.target.value)}>
                    <option value="fr">French</option>
                    <option value="de">German</option>
                </select>
            </div>
            <button onClick={handleTranslate} className="bg-blue-500 text-white px-4 py-2 rounded">
                Translate
            </button>
            {translatedText && (
                <div className="mt-3 p-2 border bg-white rounded">
                    <strong>Translated Text:</strong> {translatedText}
                </div>
            )}
        </div>
    );
};

export default TranslationForm;
