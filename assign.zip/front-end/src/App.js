import React from 'react';
import TranslationForm from './Components/TranslationForm';

function App() {
    return (
        <div className="min-h-screen flex justify-center items-center bg-gray-200">
            <TranslationForm/>
            
        </div>
    );
}

export default App;
