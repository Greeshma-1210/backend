import axios from 'axios';
import Translation from '../models/Translation.js';

export const translateText = async (req, res) => {
    const { text, sourceLang, targetLang } = req.body;

    try {
        // Call Google Translate API
        const response = await axios.post(
            `https://translation.googleapis.com/language/translate/v2`, 
            {}, 
            {
                params: {
                    q: text,
                    source: sourceLang,
                    target: targetLang,
                    key: process.env.GOOGLE_API_KEY
                }
            }
        );

        const translatedText = response.data.data.translations[0].translatedText;

        // Save translation history in MongoDB
        const newTranslation = new Translation({
            text,
            translatedText,
            sourceLang,
            targetLang
        });

        await newTranslation.save();

        res.json({ translatedText });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Translation failed', error });
    }
};
