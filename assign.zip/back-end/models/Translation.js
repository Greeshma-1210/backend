import mongoose from 'mongoose';

const translationSchema = new mongoose.Schema({
    text: { type: String, required: true },         
    translatedText: { type: String, required: true }, 
    sourceLang: { type: String, required: true },   
    targetLang: { type: String, required: true },   
    createdAt: { type: Date, default: Date.now }    
});

export default mongoose.model('Translation', translationSchema);
