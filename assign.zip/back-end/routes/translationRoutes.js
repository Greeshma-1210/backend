const express = require('express');
const { translateText } = require('../controllers/translationController.js');

const router = express.Router();
router.post('/', translateText);

export default router;
